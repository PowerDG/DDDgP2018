﻿namespace Fooww.Research
{
    public class ResearchConsts
    {
        public const string LocalizationSourceName = "Research";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
