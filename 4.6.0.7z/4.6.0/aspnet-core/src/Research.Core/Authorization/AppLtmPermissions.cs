

using System;
using System.Collections.Generic;
using System.Text;

namespace Research.Authorization
{
	/// <summary>
    /// 52abp定义的默认权限变量名称
    /// </summary>
	public class AppLtmPermissions
	{
		public const string Pages = "Pages";
		public const string Pages_Administration = "Pages.Administration";




	}
}
