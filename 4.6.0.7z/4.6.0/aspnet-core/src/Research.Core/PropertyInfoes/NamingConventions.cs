﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Research.PropertyInfoes
{
    public static class NamingConventions
    {

        public static  string GetPropertyName(string m_propertyFullName)
        {
            if (m_propertyFullName.Contains("class"))
            {
                return "This's-className";
            }
            String[] parts = m_propertyFullName.Split(" ");
            if (parts.Length<3)
            {
                return "Parts's-undercutting ";
            }
            
            return m_propertyFullName;
        }
        public static  string GetColumnFullName(string m_propertyFullName,string m_column_name)
        {//UnderscoreName(GetPropertyName(m_propertyFullName))
            if (m_propertyFullName.Contains("class"))
            {
                return "This's-className";
            }
            String[] parts = m_propertyFullName.Split(" ");
            if (parts.Length < 3)
            {
                return parts[0];
            }
            if (parts[2].Equals("class"))
            {
                return "[Column(\"" + m_column_name + "\")]" + "\n" +  m_propertyFullName;
            } 
            return m_propertyFullName;
        }



        public static  string UnderscoreName(string name)
        {
            if (name.Contains("CreationTime"))
            {
                return "create_time";
            }
            if (name.Contains("LastModificationTime"))
            {
                return "modified_time";
            }
            if (name.Contains("DeletionTime"))
            {
                return "deleted_time";
            }
            StringBuilder result = new StringBuilder();
            char[] m_list = name.ToCharArray();
            
            if (name != null && m_list.Length > 0)
            {
                // 将第一个字符处理成小写
                result.Append(name.Substring(0, 1).ToLowerInvariant());
                // 循环处理其余字符
                for (int i = 1; i < name.Length; i++)
                {
                    //String s = m_list[i];
                    // 在大写字母前添加下划线
                    if (m_list[i].ToString().Equals(m_list[i].ToString().ToUpperInvariant())
                        //&& !s.charAt(0)
                        )
                    {
                        result.Append("_");
                    }
                    // 其他字符直接转成小写
                    result.Append(m_list[i].ToString().ToLowerInvariant());
                }
            }
            return result.ToString();
        }

    }
}
