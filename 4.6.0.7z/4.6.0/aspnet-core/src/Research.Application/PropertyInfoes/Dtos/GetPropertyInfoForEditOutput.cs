

using System.Collections.Generic;
using Abp.Application.Services.Dto;
using Research.PropertyInfoes;

namespace Research.PropertyInfoes.Dtos
{
    public class GetPropertyInfoForEditOutput
    {

        public PropertyInfoEditDto PropertyInfo { get; set; }

    }
}