
using System;
using System.Data;
using System.Linq;
using System.Linq.Dynamic;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

using Abp.UI;
using Abp.AutoMapper;
using Abp.Extensions;
using Abp.Authorization;
using Abp.Domain.Repositories;
using Abp.Application.Services.Dto;
using Abp.Linq.Extensions;


using Research.PropertyInfoes;
using Research.PropertyInfoes.Dtos;
using Research.PropertyInfoes.DomainService;
using System.Text;

namespace Research.PropertyInfoes
{
    /// <summary>
    /// PropertyInfo应用层服务的接口实现方法  
    ///</summary>
    [AbpAuthorize]
    public class PropertyInfoAppService : ResearchAppServiceBase, IPropertyInfoAppService
    {
        private readonly IRepository<PropertyInfo, int> _entityRepository;

        private readonly IPropertyInfoManager _entityManager;

        /// <summary>
        /// 构造函数 
        ///</summary>
        public PropertyInfoAppService(
        IRepository<PropertyInfo, int> entityRepository
        ,IPropertyInfoManager entityManager
        )
        {
            _entityRepository = entityRepository; 
             _entityManager=entityManager;
        }



        public async Task<PagedResultDto<PropertyInfoListDto>> GetInitPaged( )
        {

            var query = _entityRepository.GetAll();
            var entityList = await query 
              .ToListAsync();
            // TODO:根据传入的参数添加过滤条件
            foreach (var item in entityList)
            {
                var _entity = _entityRepository.FirstOrDefault(t => t.Id == item.Id); 
                if (!string.IsNullOrWhiteSpace(_entity.PropertyFullName))
                {
                    _entity.PropertyName = GetPropertyName(_entity.PropertyFullName);
                    _entity.ColumnName = UnderscoreName(_entity.PropertyName);
                    _entity.PropertyNameWithColumn = GetPropertyNameWithColumn(_entity.PropertyFullName,
                             _entity.ColumnName, _entity.IsZeroModule ?? 0); 
                }
                CurrentUnitOfWork.SaveChanges();
                _entityRepository.Update(_entity); 
            } 
            var count = await query.CountAsync();
            var entityListDtos = ObjectMapper.Map<List<PropertyInfoListDto>>(entityList);  
            CurrentUnitOfWork.SaveChanges();
            return new PagedResultDto<PropertyInfoListDto>(count, entityListDtos);
        }


        public async Task<PagedResultDto<PropertyInfoListDto>> GetInitTrimStart()
        {

            var query = _entityRepository.GetAll();
            var entityList = await query
              .ToListAsync();
            // TODO:根据传入的参数添加过滤条件
            foreach (var item in entityList)
            {
                var _entity = _entityRepository.FirstOrDefault(t => t.Id == item.Id); 
                if (!string.IsNullOrWhiteSpace(_entity.ColumnFullName))
                {
                    _entity.ColumnName = GetColumnFirstName(_entity.ColumnFullName);
                    _entity.DomainName = ReplaceMigrator(_entity.ColumnFullName, _entity.ColumnName);
                } 
                _entityRepository.Update(_entity);
            }
            var count = await query.CountAsync();
            var entityListDtos = ObjectMapper.Map<List<PropertyInfoListDto>>(entityList);
            CurrentUnitOfWork.SaveChanges();
            return new PagedResultDto<PropertyInfoListDto>(count, entityListDtos);
        }

        private static string GetColumnFirstName(string m_propertyFullName)
        {
            if (m_propertyFullName.Contains("class"))
            {
                return m_propertyFullName;
            }
            String[] parts = m_propertyFullName.TrimStart().Split(" ");
            if ((string.IsNullOrWhiteSpace(m_propertyFullName) ||
                parts.Length < 3) )
            {
                return m_propertyFullName;
            }
            else if (parts[1].Equals("="))
            {

                return UnderscoreName(parts[0]);
            }
            else
            { 
                return m_propertyFullName;
            }
        }
        private static string ReplaceMigrator(string m_migratorName, string m_columnName)
        {
            if (m_migratorName.Contains("class"))
            {
                return m_migratorName;
            }
            String[] parts = m_migratorName.TrimStart().Split(" ");
            if (string.IsNullOrWhiteSpace(m_migratorName) ||
                parts.Length < 3 || !parts[1].Equals("="))
            {
                return m_migratorName;
            }
            var m_newMigratorName = m_columnName;
            for (int i = 1; i < parts.Length; i++)
            {
                m_newMigratorName += " " + parts[i];
            }
            return m_newMigratorName;
        }

        private static string GetPropertyName(string m_propertyFullName)
        {
            if (m_propertyFullName.Contains("class"))
            {
                return m_propertyFullName;
            }
            String[] parts = m_propertyFullName.Split(" ");
            if (string.IsNullOrWhiteSpace(m_propertyFullName)||parts.Length<3)
            {
                return m_propertyFullName;
            }
            return parts[2];
        }
        private static string ReNewPropertyName(string m_propertyFullName)
        {
            if (m_propertyFullName.Contains("class"))
            {
                return m_propertyFullName;
            }
            String[] parts = m_propertyFullName.Split(" ");
            if (string.IsNullOrWhiteSpace(m_propertyFullName)||parts.Length < 3)
            {
                return m_propertyFullName;
            }
            var m_newPropertyName = parts[0]+" new ";
            for (int i = 1; i < parts.Length; i++)
            {
                m_newPropertyName += " "+parts[i];
            }
            return m_newPropertyName;
        }
        public static string GetPropertyNameWithColumn(string m_propertyFullName, string m_column_name,byte isZeroModule)
        { 
            if (m_propertyFullName.Contains("class"))
            {
                return m_propertyFullName;
            }
            String[] parts = m_propertyFullName.Split(" ");
            if (string.IsNullOrWhiteSpace(m_propertyFullName)||parts.Length < 3)
            {
                return m_propertyFullName;
            }
            if (isZeroModule==1)
            { 
                return "[Column(\"" + m_column_name + "\")]" + "\n" + ReNewPropertyName(m_propertyFullName);
            }
            return "[Column(\"" + m_column_name + "\")]" + "\n" + m_propertyFullName; 
        }
         
        public static string UnderscoreName(string name)
        {
            if (name.Contains("CreationTime"))
            {
                return "create_time";
            }
            if (name.Contains("LastModificationTime"))
            {
                return "modified_time";
            }
            if (name.Contains("DeletionTime"))
            {
                return "deleted_time";
            }
            StringBuilder result = new StringBuilder();
            char[] m_list = name.ToCharArray();
            if (name != null && m_list.Length > 0)
            {  // 将第一个字符处理成小写
                result.Append(name.Substring(0, 1).ToLowerInvariant()); 
                for (int i = 1; i < name.Length; i++)
                {
                    if (m_list[i].ToString().Equals(m_list[i].ToString().ToUpperInvariant())  )
                    { // 在大写字母前添加下划线
                        result.Append("_");
                    } // 其他字符直接转成小写
                    result.Append(m_list[i].ToString().ToLowerInvariant());
                }
            }
            return result.ToString(); 
        }


        /// <summary>
        /// 获取PropertyInfo的分页列表信息
        ///</summary>
        /// <param name="input"></param>
        /// <returns></returns>

        public async Task<PagedResultDto<PropertyInfoListDto>> GetPaged(GetPropertyInfosInput input)
		{

		    var query = _entityRepository.GetAll();
			// TODO:根据传入的参数添加过滤条件
            

			var count = await query.CountAsync();

			var entityList = await query
					.OrderBy(input.Sorting).AsNoTracking()
					.PageBy(input)
					.ToListAsync();

			// var entityListDtos = ObjectMapper.Map<List<PropertyInfoListDto>>(entityList);
			var entityListDtos =entityList.MapTo<List<PropertyInfoListDto>>();

			return new PagedResultDto<PropertyInfoListDto>(count,entityListDtos);
		}


		/// <summary>
		/// 通过指定id获取PropertyInfoListDto信息
		/// </summary>
		 
		public async Task<PropertyInfoListDto> GetById(EntityDto<int> input)
		{
			var entity = await _entityRepository.GetAsync(input.Id);

		    return entity.MapTo<PropertyInfoListDto>();
		}

		/// <summary>
		/// 获取编辑 PropertyInfo
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		
		public async Task<GetPropertyInfoForEditOutput> GetForEdit(NullableIdDto<int> input)
		{
			var output = new GetPropertyInfoForEditOutput();
PropertyInfoEditDto editDto;

			if (input.Id.HasValue)
			{
				var entity = await _entityRepository.GetAsync(input.Id.Value);

				editDto = entity.MapTo<PropertyInfoEditDto>();

				//propertyInfoEditDto = ObjectMapper.Map<List<propertyInfoEditDto>>(entity);
			}
			else
			{
				editDto = new PropertyInfoEditDto();
			}

			output.PropertyInfo = editDto;
			return output;
		}


		/// <summary>
		/// 添加或者修改PropertyInfo的公共方法
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		
		public async Task CreateOrUpdate(CreateOrUpdatePropertyInfoInput input)
		{

			if (input.PropertyInfo.Id.HasValue)
			{
				await Update(input.PropertyInfo);
			}
			else
			{
				await Create(input.PropertyInfo);
			}
		}


		/// <summary>
		/// 新增PropertyInfo
		/// </summary>
		
		protected virtual async Task<PropertyInfoEditDto> Create(PropertyInfoEditDto input)
		{
			//TODO:新增前的逻辑判断，是否允许新增

            // var entity = ObjectMapper.Map <PropertyInfo>(input);
            var entity=input.MapTo<PropertyInfo>();
			

			entity = await _entityRepository.InsertAsync(entity);
			return entity.MapTo<PropertyInfoEditDto>();
		}

		/// <summary>
		/// 编辑PropertyInfo
		/// </summary>
		
		protected virtual async Task Update(PropertyInfoEditDto input)
		{
			//TODO:更新前的逻辑判断，是否允许更新

			var entity = await _entityRepository.GetAsync(input.Id.Value);
			input.MapTo(entity);

			// ObjectMapper.Map(input, entity);
		    await _entityRepository.UpdateAsync(entity);
		}



		/// <summary>
		/// 删除PropertyInfo信息的方法
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		
		public async Task Delete(EntityDto<int> input)
		{
			//TODO:删除前的逻辑判断，是否允许删除
			await _entityRepository.DeleteAsync(input.Id);
		}



		/// <summary>
		/// 批量删除PropertyInfo的方法
		/// </summary>
		
		public async Task BatchDelete(List<int> input)
		{
			// TODO:批量删除前的逻辑判断，是否允许删除
			await _entityRepository.DeleteAsync(s => input.Contains(s.Id??-1));
		}


		/// <summary>
		/// 导出PropertyInfo为excel表,等待开发。
		/// </summary>
		/// <returns></returns>
		//public async Task<FileDto> GetToExcel()
		//{
		//	var users = await UserManager.Users.ToListAsync();
		//	var userListDtos = ObjectMapper.Map<List<UserListDto>>(users);
		//	await FillRoleNames(userListDtos);
		//	return _userListExcelExporter.ExportToFile(userListDtos);
		//}

    }
}


