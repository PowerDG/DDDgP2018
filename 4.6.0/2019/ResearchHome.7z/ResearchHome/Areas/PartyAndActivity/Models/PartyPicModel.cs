﻿using System.Collections.Generic;

namespace ResearchHome.Areas.PartyAndActivity.Models
{
    public class PartyPicModel: PartyModel
    {
        public List<PartyImgModel> PartyImgList { get; set; }
    }
}
