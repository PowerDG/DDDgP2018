﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ResearchHome.Areas.Introduction.Models;
using ResearchHome.Controllers;
using ResearchHome.DataBase;
using ResearchHome.Helper;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ResearchHome.Areas.Introduction.Controllers
{
    [Area("Introduction")]
    public class ReadBooksController : BaseController
    {
        private readonly IDatabase database;
        private IHostingEnvironment environment;
        private readonly IConfiguration configuration;
        public ReadBooksController(IDatabase database, IHostingEnvironment hostingEnvironment, IConfiguration configuration)
        {
            this.database = database;
            this.environment = hostingEnvironment;
            this.configuration = configuration;
        }

        public async Task<JsonResult> GetReadBooks(int memberId, int page, int limit)
        {
            string sql = $@"SELECT book_comment.id AS Id,book.`Name` AS Name,book.Photo,book.PhotoHD,book.Author,
                        book_comment.create_time ,book_comment.member_id AS MemberId,book_comment.`comment` AS Commentary
                         FROM book_comment,book WHERE member_id ={memberId} AND book_comment.book_id=book.Id 
                          ORDER BY create_time DESC LIMIT {(page - 1) * limit}, {limit}";
            var records = database.QueryListSQL<ReadBooks>(sql).ToList();
            string sqlCount = $"SELECT COUNT(*) AS Count FROM book_comment WHERE member_id= {memberId}";
            var count = await database.ExecuteScalarAsync(sqlCount);
            return Json(new { code = 0, msg = "查询成功", count, data = records });
        }

        public IActionResult EditReadBook(int memberId, int bookId)
        {
            ViewBag.MemberId = memberId;
            string querySQL = $"SELECT * FROM book WHERE id = {bookId}";
            var book = database.Single<ReadBooks>(querySQL);
            return View(book);
        }

        [HttpPost]
        public async Task<JsonResult> EditReadBook(ReadBooks book)
        {
            bool result = false;
            if (!string.IsNullOrEmpty(book.Photo))
            {
                var photo = PictureHelper.UploadPicture("FileUpload", book.Photo, configuration, environment);
                book.Photo = photo.Item2;
                book.PhotoHD = photo.Item1;
            }
            if (book.Id > 0)
            {
                System.Text.StringBuilder sql = new System.Text.StringBuilder($"UPDATE book SET Name = '{book.Name}', Author = '{book.Author}', Commentary = '{book.Commentary}' ");
                if (!string.IsNullOrEmpty(book.Photo))
                {
                    sql.Append($", Photo = '{book.Photo}', PhotoHD = '{book.PhotoHD}'");
                }
                sql.Append($" WHERE Id = {book.Id}");
                result = database.ExecuteSQL(sql.ToString());
            }
            else
            {
                book.CreateTime = DateTime.Now;
                result = await database.CreateAsync<ReadBooks>(book) > 0;
            }
            return Json(new { success = result, message = result ? "操作成功" : "操作失败" });
        }

        [HttpPost]
        public JsonResult DeleteBook(int id)
        {
            bool result = false;
            string sql = $"DELETE FROM book WHERE Id = {id}";
            result = database.ExecuteSQL(sql);
            return Json(new { success = result, message = result ? "删除成功" : "删除失败" });
        }
    }
}