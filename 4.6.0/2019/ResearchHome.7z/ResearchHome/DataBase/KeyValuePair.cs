﻿namespace ResearchHome.DataBase
{
    public class KeyValuePair<TKey, TValue, Type>
    {
    }
}