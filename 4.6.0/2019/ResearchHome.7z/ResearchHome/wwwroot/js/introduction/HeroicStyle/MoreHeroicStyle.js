﻿window.onload = function () {
    importPartContent("/Introduction/HeroicStyle/HeroicStyle", function (res) {
        $('#heroicStylePartContent').empty().append(res);
        heroicStyleFristLoad("showAll");
    });
};