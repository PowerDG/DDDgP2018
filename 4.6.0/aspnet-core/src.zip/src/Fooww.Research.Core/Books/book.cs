﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fooww.Research.Books
{
    public class book
    {


        public string name { get; set; }
     }
}
